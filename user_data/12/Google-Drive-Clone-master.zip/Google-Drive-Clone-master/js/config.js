const firebaseConfig = {
    apiKey: "AIzaSyBpsBdBbaUvAe04KywoN2caAPf9T69_IGQ",
    authDomain: "drive-clone-cb216.firebaseapp.com",
    projectId: "drive-clone-cb216",
    storageBucket: "drive-clone-cb216.appspot.com",
    messagingSenderId: "1098261564496",
    appId: "1:1098261564496:web:1d76ea6f495a8b63295555",
    measurementId: "G-7SB9S4NDNG"
  };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);