# Google-Drive-Clone
## Still in Development
## [See Demo Here](https://faiezwaseem.github.io/Google-Drive-Clone/)
### Features
 - [x] Folder CRUD
 - [x] File Sharing
 - [x] Folder Sharing
 - [x] Multiple File Sharing
 - [x] search file / Folder
 - [x] Create Folder
 - [x] Multiple File Delete
 - [x] Dark Mode
 - [x] Drag Drop Upload
 - [ ] Sub Folders
